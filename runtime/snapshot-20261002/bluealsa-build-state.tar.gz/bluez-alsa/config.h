/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Directory containing ALSA add-on configuration files. */
#define ALSA_CONF_DIR "/usr/share/alsa/alsa.conf.d"

/* Directory containing ALSA add-on modules. */
#define ALSA_PLUGIN_DIR "/home/wnk/LicheePi_Nano/buildroot-2018.02.11/output/host/bin/../arm-buildroot-linux-gnueabi/sysroot/usr/lib/alsa-lib"

/* Define to 1 if the debugging is enabled. */
/* #undef DEBUG */

/* Define to 1 if the debug timing is enabled. */
/* #undef DEBUG_TIME */

/* Define to 1 if AAC is enabled. */
/* #undef ENABLE_AAC */

/* Define to 1 if apt-X is enabled. */
/* #undef ENABLE_APTX */

/* Define to 1 if apt-X HD is enabled. */
/* #undef ENABLE_APTX_HD */

/* Define to 1 if LDAC is enabled. */
/* #undef ENABLE_LDAC */

/* Define to 1 if MP3LAME is enabled. */
/* #undef ENABLE_MP3LAME */

/* Define to 1 if MPEG is enabled. */
/* #undef ENABLE_MPEG */

/* Define to 1 if MPG123 is enabled. */
/* #undef ENABLE_MPG123 */

/* Define to 1 if mSBC is enabled. */
/* #undef ENABLE_MSBC */

/* Define to 1 if oFono is enabled. */
/* #undef ENABLE_OFONO */

/* Define to 1 if PAYLOADCHECK is enabled. */
#define ENABLE_PAYLOADCHECK 1

/* Define to 1 if UPower is enabled. */
/* #undef ENABLE_UPOWER */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the `splice' function. */
#define HAVE_SPLICE 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "bluez-alsa"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "arkadiusz.bokowy@gmail.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "bluez-alsa"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "bluez-alsa 2.1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "bluez-alsa"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.1.0"

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Enable extensions on AIX 3, Interix.  */
#ifndef _ALL_SOURCE
# define _ALL_SOURCE 1
#endif
/* Enable GNU extensions on systems that have them.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE 1
#endif
/* Enable threading extensions on Solaris.  */
#ifndef _POSIX_PTHREAD_SEMANTICS
# define _POSIX_PTHREAD_SEMANTICS 1
#endif
/* Enable extensions on HP NonStop.  */
#ifndef _TANDEM_SOURCE
# define _TANDEM_SOURCE 1
#endif
/* Enable general extensions on Solaris.  */
#ifndef __EXTENSIONS__
# define __EXTENSIONS__ 1
#endif


/* Version number of package */
#define VERSION "2.1.0"

/* Define to 1 if on MINIX. */
/* #undef _MINIX */

/* Define to 2 if the system does not provide POSIX.1 features except with
   this defined. */
/* #undef _POSIX_1_SOURCE */

/* Define to 1 if you need to in order for `stat' and other things to work. */
/* #undef _POSIX_SOURCE */
