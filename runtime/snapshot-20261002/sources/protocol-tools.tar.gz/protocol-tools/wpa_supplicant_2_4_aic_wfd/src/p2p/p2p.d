../src/p2p/p2p.o: ../src/p2p/p2p.c \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/includes.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/build_config.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/common.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/os.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/wpa_debug.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/wpabuf.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/eloop.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/ieee802_11_defs.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/ieee802_11_common.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/wpa_ctrl.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/crypto/sha256.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/crypto/crypto.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/wps/wps_i.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/wps/wps.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/wps/wps_defs.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/wps/wps_attr_parse.h \
 ../src/p2p/p2p_i.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/list.h \
 ../src/p2p/p2p.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/wps/wps_defs.h
