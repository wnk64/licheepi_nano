../src/drivers/driver_nl80211_event.o: \
 ../src/drivers/driver_nl80211_event.c \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/includes.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/build_config.h \
 /usr/include/libnl3/netlink/genl/genl.h \
 /usr/include/libnl3/netlink/netlink.h \
 /usr/include/libnl3/netlink/netlink-compat.h \
 /usr/include/libnl3/netlink/version.h \
 /usr/include/libnl3/netlink/errno.h /usr/include/libnl3/netlink/types.h \
 /usr/include/libnl3/netlink/handlers.h \
 /usr/include/libnl3/netlink/netlink-kernel.h \
 /usr/include/libnl3/netlink/socket.h \
 /usr/include/libnl3/netlink/object.h /usr/include/libnl3/netlink/utils.h \
 /usr/include/libnl3/netlink/list.h /usr/include/libnl3/netlink/msg.h \
 /usr/include/libnl3/netlink/attr.h /usr/include/libnl3/netlink/addr.h \
 /usr/include/libnl3/netlink/data.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/common.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/os.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/wpa_debug.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/wpabuf.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/eloop.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/qca-vendor.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/qca-vendor-attr.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/ieee802_11_defs.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/ieee802_11_common.h \
 ../src/drivers/driver_nl80211.h ../src/drivers/nl80211_copy.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/list.h \
 ../src/drivers/driver.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/defs.h
