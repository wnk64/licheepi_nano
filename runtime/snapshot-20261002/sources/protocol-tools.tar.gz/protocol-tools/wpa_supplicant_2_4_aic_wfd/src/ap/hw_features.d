../src/ap/hw_features.o: ../src/ap/hw_features.c \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/includes.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/build_config.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/common.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/os.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/wpa_debug.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/wpabuf.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/eloop.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/ieee802_11_defs.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/ieee802_11_common.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/wpa_ctrl.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/hw_features_common.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/drivers/driver.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/defs.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/list.h \
 ../src/ap/hostapd.h ../src/ap/ap_config.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/ip_addr.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/wpa_common.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/wps/wps.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/wps/wps_defs.h \
 ../src/ap/ap_drv_ops.h ../src/ap/acs.h ../src/ap/ieee802_11.h \
 ../src/ap/beacon.h ../src/ap/hw_features.h
