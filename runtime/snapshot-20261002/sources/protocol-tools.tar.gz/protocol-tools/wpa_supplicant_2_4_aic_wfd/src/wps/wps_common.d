../src/wps/wps_common.o: ../src/wps/wps_common.c \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/includes.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/build_config.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/common.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/os.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/wpa_debug.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/utils/wpabuf.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/defs.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/common/ieee802_11_common.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/crypto/aes_wrap.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/crypto/crypto.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/crypto/dh_group5.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/crypto/sha1.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/crypto/sha256.h \
 /home/wnk/LicheePi_Nano/third_party/wpa_supplicant_2_4_aic_wfd_arm_board_20260723/src/crypto/random.h \
 ../src/wps/wps_i.h ../src/wps/wps.h ../src/wps/wps_defs.h \
 ../src/wps/wps_attr_parse.h ../src/wps/wps_dev_attr.h
