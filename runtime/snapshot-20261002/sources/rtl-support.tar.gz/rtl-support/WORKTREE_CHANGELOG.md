# Worktree Change Log

## 2026-09-30 / pending phone / new-board Miracast runtime startup
Plan: restore verified manual 5745MHz GO/PBC/DHCP/FIFO/native90-degree player.
Base5baac56 and deployed 15MHz BS management; do not change kernel/driver/player.
Record: f1c200s/newboard_miracast_20260930.md (Chinese detailed commands/results).
Observed: existing checked loader/rxguard, 8d80->8d83->wlan1, both vermagic5.7.1.
WFD setup all OK, GO DIRECT-VJ AP-ENABLED/COMPLETED; native player waits FIFO.
DHCP/request-triggered PBC/RTSP observers alive, no phone request yet.
BS route/SSH unchanged; same boot ID; MemAvailable20464KiB before streaming.
No source/binary/startup replacement, no build, no GitHub push. Pending visual
phone test, cold-boot acceptance0/3. Runtime helpers retained for active test.

## 2026-09-30 / planned / BS SDIO 15MHz
User requests 15MHz. Base b7247f9, tag bs-before-15mhz-20260930;
full source bundle: /home/wnk/F1C200S_archives/bs_15mhz_20260930/before-driver-source.bundle.
Kernel source 165df40, complete archive bs_poll_candidate_20260930, release 5.7.1.
Only change: BS DTS MMC1 max-frequency 6000000 -> 15000000.
Keep one-bit bus and allwinner,sdio-irq-polling. No kernel/modules rebuild.
Protected: MMC0/rootfs, AIC/MUSB, display, RTC/TCA/IP, UART BT and startup/audio.
Rollback: board /root/aic_miracast/candidates/bs_15mhz_20260930/rollback/
suniv-f1c100s-licheepi-nano.dtb, MD5 d7016a6eeca0c2f0fa1c86adf90ae3b7.
Build: existing GCC preprocessor and kernel scripts/dtc/dtc; DTB only.
Tests planned: one software boot, auto BS SSH, actual MMC1 ios, short traffic.
Decision pending; no stable acceptance or GitHub push.
Source commit 6a558a5. DTB-only build succeeded; MD5 0b0ab18eb88f3bb7be12426e797cae38.
Decompiled old/new DTB diff contains only MMC1 max-frequency, 6MHz -> 15MHz.
Transferred and verified board candidate and FAT target; zImage unchanged.
Boot FAT unmounted before reboot. Initial plain reboot command was absent from
SSH PATH; explicit /sbin/reboot succeeded. Runtime verification pending.
Runtime: boot b1b1d3d9-9a4b-475a-b434-3708d726e69c, unchanged 5.7.1 #248.
MMC1 ios requested/actual 15000000Hz, 1-bit, 3.3V, high-speed. BS auto-SSH
10.0.0.234/default route rtlwlan0; association 7.32s. Gateway ping10/10.
SSH payload board->PC 2097152 bytes/2.2332164s=7.51258Mbit/s, rc0;
PC->board wc count2097152/3.9496918s=4.24773Mbit/s, rc0. Includes SSH overhead.
No MMC1 CRC/data/timeout errors after traffic. Initial PC reader syntax failed;
terminated its specific plink process, reran with a valid byte buffer.
HCI UP RUNNING/errors0; headphone default, DRM card0/RTC0 present. Startup and
asound hashes unchanged; AIC/BU unloaded. No Bluetooth audio/Miracast test.
Existing regulatory.db missing and MUSB unknown readb120/121 boot warnings
remain; not addressed by this clock change. Debugfs and boot FAT unmounted.
Decision: deployed candidate, short checks pass, zero cold-boot acceptance cycles;
no stable claim or GitHub push. Rollback file above remains available.

## 2026-09-30 / planned / soldered RTL8723BS first deployment and retire BU
Base887f0cb, tagbefore-bs-first-deploy-20260930; BS full source/config/matched
candidate archive rtl8723bs_candidate_20260930. User confirms BS now soldered.
Current home consoleCOM9, AIC98:a1:4a:08:13:6a at10.0.0.170 after serial recovery.
HomeWPA added via control commands, saved using supplicant withmode600; private
credential stays board-only, not Git/logs. UbuntuVM restarted, original trees.
Boardbaseline5.7.1 #246, boot0b64c804-72b4-4831-a8b8-c8bdf25e455f,
8723BU erroneously loaded despite no USB0bda:b720; SDIO nodes not enabled yet.
Files:startup/S17rtl8723bu,S45usb-wifi,S44musb-reprobe and records.
Change:S17/S45 immediate no-op eliminates BU insertion and obsolete wait;
S44 retains USB recovery but removes BU unload/reload calls. Keep driver binary
for rollback, don't disturb AIC/earpiece autoaudio or other board services.
Deploy:matched BS kernel75da971/DTB4062283/modulepackage9a475323122a1690e73731efb460f3b7,
firmware viaSSH, preserve current FAT files and modules separately, numeric hashes
before reboot. Test SDIO enumeration first, load WLAN manually, then Bluetooth.
Decision:pending; no GitHub push, stress tests or stable acceptance claim.

Startup source4ffe4bb deployed with oldscripts retained in board
/root/aic_miracast/candidates/rtl8723bs_first_20260930/rollback.
Kernel/DTB rollback2b9b8cf3f41d88fc7182be2c63bcdf22/670b67cf44be2d21acdca82dab9e3d4b.
Candidate75da971/4062283 files checked on FAT then sync/unmount, BS firmware
installed, coreUSB/Cedar module hashes identical. BU unloaded before reboot.
Software boot#247, bootIDb3fb2bc9-1d13-48f6-a0d0-02e6a645e474; no8723bu module.
SDIO mmc1:0001:1 vendor024c/deviceb723; UART2 serdev registered, AIC DHCP around8s
at10.0.0.170 without serial intervention. card0/rtc0 present, routeheadphone.
Loader failed before insertion due SSH PATH missing/sbin. Add explicitPATH to
both tracked load tools; manual insmod uses /sbin. Not a driver failure.

LoaderPATH sourcea7b3e2b. BS module registered rtlwlan0 MAC04:4a:69:9d:1a:0e;
at25MHz/1bit/3.3V the interface startup firmware request causes MMC1 data errors.
Runtimedebugfs clock6MHz and module reload produced no new data-error lines,
but iw/iwlist scan empty; lowering clock alone is not WLAN acceptance.
BT externalH5 binds serial0-0; recognizes HCIver6/revb, BS fw/config downloaded,
fwversion1e4cc3ff, hci0 address04:4a:69:c0:46:a8 UP RUNNING/error0. Backend
starts bluetoothd/BlueALSA; inquiry sees PC A8:E2:91:37:C3:DF WNK. No pairing/audio
test performed. Headphone route retained, no BT speaker connected.
Next narrow candidate:MMC1 max-frequency6MHz in BS-only DTS to allow clean
power-sequence/firmware init at low clock; preserve25MHz candidate archive.
No MUSB/kernel driver changes. Build/DTB deployment/reboot test pending.

Low-clock source466c344, DTB1347282956e96b9c9318a0377f60af30 installed;
software bootb07cc358-a649-4a76-b918-edfa2233ea0b, #247, scan still empty
without new CRC/data errors. Low clock alone not accepted as WLAN fix.
Next hypothesis:DAT1 missing means in-band IRQ unavailable even on1bit bus.
Optional kernelMMC property clears MMC_CAP_SDIO_IRQ to select native polling;
BS DTS opts in only MMC1. Full kernel pre-change archive/tag captured. Sources
tracked before incrementalkernel/modules/BS/H5 build. No hardware/MUSB edits.

Polling implementation:kernele7f7cc9, runtime128f43b; tmux numericrc0, all
modules5.7.1. zImage2d16ba197f384e0570071aabf2094c44, DTBd7016a6eeca0c2f0fa1c86adf90ae3b7,
package19b24694944ee24bb5259a4123905def; full source/artifacts/generated-state
archived bs_poll_candidate_20260930 before deployment. Rollback prior #247
75da971/134728DTB in board rtl8723bs_poll_20260930/rollback; core modules same.
Software boot#248 shows MMC1 polling log, scans30+2.4GHz BSS including
wnk641_2.4G signal-45dBm. No newMMC1data errors. Polling explains missing
scan events;25MHz timing errors are separately mitigated by6MHz, not proven
electrical root cause. MMC0/rootfs and AIC/Codec/display/RTC remain available.
Next scoped runtime integration:S48 loads proven BS WLAN/H5 from explicit
candidate directory, brings up rtlwlan0 without changing IP/default routes;
S35 handles audio backend when HCI appears. Provisional auto-load, not stable
acceptance. Wi-Fi password match asked before association; credentials private.

S48source1aa7be5 installed MD53d123b0319375f61b4f19aaa1382789f; manual start
returns0 on already-loaded drivers. BU startup no-opd0fd356ccab5aa32c816dc67009f8c47,
legacy Wi-Fi wait no-op490bb6a7cf5681471324a89027697638,
USB recovery5ea9ec1b482e4e44d9d157ad8e136687, no BUload/reload calls remain.
Polling bootf81ecb68-9c36-427e-9e42-ccc1322483b5, BTfirmware1e4cc3ff,
hci0UP/error0; BlueALSA ManagerGetPCMs replies empty (no speaker connected),
audio routeheadphone. Baseline audio/AIC/IP service hashes unchanged.

User confirmed2.4GHz Wi-Fi shares5GHz password. Add narrow DHCP test hook:
configure onlyrtlwlan0 IPv4/netmask, never rewrite default route/DNS or AIC IP.
Credentials configured through WPA control, not Git; this is runtime association
test, not unrequested persistent BS management migration.

BS association test completed:wnk641_2.4G BSSID50:4f:3b:cc:67:52 channel1,
WPA2/CCMP COMPLETED, DHCP10.0.0.234. ping-Irtlwlan0 gateway10.0.0.1 5/5,
0loss,6.462/20.156/27.378ms; AIC10.0.0.170/default route remains wlan0.
BS association is runtime-only via /run/rtl-bs-wpa, credentials not archived.
User powered Bluetooth speaker and authorized connection/playback test.
Current inquiry observes12:11:71:41:9C:4A Wt-070 and PCWNK; target speaker
selected from fresh scan, not merely cached address. Planned pair/connect then
verify A2DP PCM and automatic-default route; quiet sample/volume only after
connection. No driver/kernel changes; pairing persists BlueZ state, rollback
disconnect/remove only this test speaker if needed. Not stable acceptance.

Wt-070 pair/trust/connect succeeded with fresh scan. A2DP PCM/source,
48000Hz/stereo/SBC, route automatically bluetooth12:11:71:41:9C:4A.
No player change. Planned quiet4s stereo WAV fixture generated with stdlibwave,
-36dBFS peak/ramped440 then660Hz, for user audible confirmation. Control alias
bluealsa missing in global config (amixer-Dbluealsa fails), independent of
direct PCM configuration; do not assume that error means playback failed.
Test silence first, then quiettone, disconnect to verify new-stream headphone
fallback, reconnect to leave speaker available. Do not claim sound heard until
user confirmation. Fixture generator tracked; temporary boardWAV removed after.

User confirmed quiet test sound audible onWt-070. Successful pairing/A2DP
write/audio evidence; not long-term stability. Speaker disconnect caused route
headphone, as observed afterward; interrupted before silentPCM verification.

## 2026-09-30 / planned / BS primary STA + SSH, AIC casting only
User explicitly requests persistent BS Wi-Fi/SSH autostart and faster boot,
no AIC ordinary networking. Base65a160d, tagbefore-bs-primary-network-20260930.
BS10.0.0.234 SSH independently verified; AIC10.0.0.170 retained during migration.
Files:f1c200s/bs_primary_network_20260930 S17STA/S18SSH/S46AIC/S48BT,
secret-free WPA template, on-demand AIC module registration tool.
Change:BS WLAN/firmware early, WPA/DHCP worker background (non-blocking startup),
SSH listen early; private /etc/rtl8723bs-sta.conf saved by WPA control. Default
route and DNS belong to BS after transition. AIC bootSTA replaced by no-op;
retain source-backed AIC artifacts and explicit manualMiracast loader only,
register wlan1 without STA/DHCP. Existing casting/player scripts unchanged.
Protected:SDIOpoll/6MHz kernel, headphone/I2S-off/BT autoaudio, display/RTC/IP.
Rollback:boardbs_primary_network_20260930/rollback previousS46/S48 and BU no-ops
remain. Stop only AIC's recorded WPA/DHCP, migrate via verifiedBS SSH, reboot
once to verify automatic network and absence of BU/AIC drivers. No credentials
in Git or docs. No GitHub push/physical cold-boot acceptance claim.

Primary-network implementation16fbe5c deployed. BS privateWPA config stored600;
SSH10.0.0.234 verified, AIC's recorded WPA/DHCP stopped, AIC drivers removed,
BS route primary,3/3gatewayping no loss. No killall/unrelated service edits.
User reboot verified boot13c988c0-74d6-44b0-8f39-09c1f615d810, #248,
BS autoassociatedwnk641_2.4G/channel1 and DHCP10.0.0.234, default/devrtlwlan0,
noAIC/BU modules. WLAN module~4.04s, firmware~4.30s, assoc~8.74s kernel time.
BT hci0 automaticUP/error0, routeheadphone, Codec/card0/rtc0 intact. User reports
noticeably faster boot. No exact power-on-to-SSH time measurement claimed.
User asks DAT1-to-GPIO feasibility and throughput; no request to change wiring
or drivers. Explain externalGPIOIRQ requires host/driver wiring, not automatic
nativeSDIO pin equivalence. Current6MHz/1bit rawceiling6Mbit/s (0.75MB/s).
Add reusable one-request stdlibHTTP fixture for4MiB RAM-to-/dev/null LAN speed,
not SSH encryption/storage benchmark, no stress/caching/file payload on board.
Short measurement pending; no network/firewall settings changes.

Shortthroughput:one-request4MiB HTTP listener10.0.0.129:8765 exited normally
without a request; boardwget5s timeout. No firewall mutation. Fallback uses
SSH/dd zero stream drained/count-only on host:2097152bytes in4.201s,
0.499MB/s/3.994Mbit/s,rc0,512records. Label as measuredboard->PC SSHpayload,
not rawTCP/Wi-Fi rate; includesSSH setup/encryption, no SD writes or long stress.
No DAT1 wiring/driver modifications made for user's feasibility question.
User reboot verifies primary network plus automaticBS/HCI initialization.
No AIC/BU modules; user requested AIC exclusivelycasting, so on-demand loader
kept but not invoked/newcasting not claimed. Pairing/audio previouslyconfirmed
by user; currently speaker disconnected after earlier test/reboot, routeCodec.
Final archive:/home/wnk/F1C200S_archives/bs_primary_network_20260930 with source
bundle/README/scripts/hashes and separate authoritativekernel #248 archive.
Temporarytest WAV removed onboard and VM, local generated fixture removed;
HTTP listener and interactivebluetoothctl sessions ended, no helpers left.
Decision:driver enumeration/WLAN scan/BT initialization implemented and directly
tested, association/pairing/audio and stable acceptance pending. No unsolicited
speaker pairing. New startup tested manually, next boot verification pending.

## 2026-09-30 / planned / user correction to RTL8723BS
Base:b8d4c13; tagbefore-rtl8723bs-correction-20260930. Kernel2360bde, tracked clean,
CONFIG_RTL8723BS=m already enabled. Full source/config/artifacts in BT and
headphone archives; retain DS candidates as historical, do not delete them.
Files:newboard_rtl8723bs_20260930 DTS/build/loaders/BS firmware/provenance;
shared externalH5 adds rtl8723bs-bt OF match, leaves DS support for rollback.
WLAN:use genuine in-tree staging r8723bs, IDs024c:0523/0525/0623/0626/b723,
request rtlwifi/rtl8723bs_nic.bin. Not DS ID/model substitution.
BT:btrtl already identifies BS HCIrev0xb/ver6; resolves BS firmware/config
symlinks to actual8723b blobs, checked signatures/UART1.5M+flowcontrol.
Hardware:retain user-confirmed bus/reset/wake mapping; physical module pin
compatibility requested, not inferred. Hardware still absent, no deployment.
Build:tmux, LOCALVERSION=release5.7.1, only existing BS and stagedH5 modules
plus newDTB; no .config/zImage/source driver edits or full rebuild. I2S remains
disabled, headphone/BT autoaudio and AIC board services untouched.
Decision:pending compile/hardware; no new worktree or GitHub push.

User confirmed the purchased BS module has the same pinout; no wiring changes.
Sourceface19e, tmux f1-rtl8723bs-0930 numericrc0; WLANr8723bsMD5
b84ea759d436ab6fd3cc0d3585107ad1, externalH5MD5
2ce367907d511e13ddbdcc7c2c7dd223, combinedBS DTB406228300a5b8cfd0040c769030864c3.
All7package modules vermagic5.7.1. No DS module or firmware in BS package.
Pinned resolvedBS firmware/config signature/UART validated, not symlink text.
DTB confirms BS WLAN/BT compatible,1bit bus, P01 reset/P03enable/P04wake/P02input,
I2Sdisabled/Codecokay. Missing-device Wi-Fi load test returns nonzero/no module.
Kernel config0361a6dd67d2d74f23dcb147148e8d38 and candidatezImage
75da971835ca3339b47eb649c2cf6697 unchanged. Kernel tracked state clean.
Running board unchanged #246, routeheadphone; AIC/IP/asound/S35hashes unchanged.
Decision:BS is selected future module candidate, compile-verified only; hardware
installation/network/BT/coexistence/suspend tests pending. No deployment/reboot.
Archive:/home/wnk/F1C200S_archives/rtl8723bs_candidate_20260930.
Temporary commit/finalization wrappers removed; repeatable build/loaders retained.

## 2026-09-30 / planned / automatic default audio selection
Base9ad5ab8, tagbefore-auto-audio-route-20260930; headphone archive and full
BlueALSA source82fdaea18130bf7b0c83a5e2566ddd4249901c82/build state preserved.
Files:f1c200s/audio_route_20260930 C selector using upstream structured DBus
client, config hooks, SysV startup/backend supervision and reproducible build.
User chose new playback selection only, not mid-stream migration. Detect
A2DP SOURCE PCM with valid format parameters; retain current speaker if still
available; disconnect/service failure restores headphone. No fixed speaker MAC.
Static Codec fallback remains if /run config absent. ctl always Codec; Bluetooth
playback default uses asym to retain Codec microphone capture.
Restore source-backed BlueALSA/SBC runtime dependencies; enable daemons only
when an HCI adapter appears, no hardware module loading/pairing or kernel change.
Protected:headphone/I2S-off, AIC/display/RTC/IP. Rollback:audio_route_20260930/rollback.
Build/tests/decision:pending. No Bluetooth hardware installed, no real switch
or speaker playback acceptance claim; no GitHub push or new worktree.

Initial source5c9d473 compiled; source-backed BlueALSA runtime dependencies
deployed. PCM plugin unchanged80a26b633a2ee1636e6c13b21ae5a232; new ctl
plugin27ebd4f0d6cefda6645f1a2875cc0951, SBCeeb85c916291699bd9eb331f0f457642,
BlueALSA341ca3171112f5c0f6c2861ca37981b1. Package transfer MD5 checked.
Self-test passed:empty/SCO/capture-only/invalid format rejected, stable speaker
selection and vanished-current fallback. Board no HCI, service headphone,
default48k stereo1s silence successful. Repeated start preserves two original
PIDs; selector RSS1452kB. No daemon started without adapter.
Follow-up source fixes:touch global asound config mtime on route changes to
invalidate cached ALSA config for later PCM opens; don't duplicate a still-live
backend if only the selector was stopped. No mid-stream switching implemented.

Final implementation35be204; selectorMD5a172ec0fcaa4ba232ca73b90d95920a7,
S35MD5acb10974517210f41ee360861d858cfe, asoundMD5a3bd2f9ade5b0b4390b16261d9725bb0.
Updated package transferred; stopped owned processes before replacing executable.
Self-test passed again. Deleted only generated /run route files while stopped;
static-fallback default playback passed, service restart and runtime-fallback
default playback passed. Both1s48kHz stereo silence. No kernel/DTB/reboot change.
Board retains #246, disabled I2S, headphone volume40/63; AIC/IP service hashes
unchanged. No HCI available, no realBluetooth switching/listening test possible.
Decision:implemented/deployed for new stream selection, hardware acceptance pending.
Rollback:stop service, restore candidate/rollback/asound.conf, remove newS35
and runtime route files; retain originalS20headphone. Owned BlueZ/BA only stopped
by backend trap. No arbitrary player/module/daemon killall.
Archive:/home/wnk/F1C200S_archives/audio_route_20260930; source bundle plus
BlueALSA/SBC source/build config/runtime packages. No GitHub push.
Temporary wrappers removed; durable tools retained. Long waiting bluetoothctl
inspection owned by this task was stopped; no diagnostic SSH process left running.

## 2026-09-30 / planned / headphone runtime default
Base:b4cefcb; tagged before-headphone-runtime-20260930; original kernel695543f.
Files:f1c200s/headphone_20260930/asound.conf,S20headphone,build tool and records;
Wi-Fi candidate DTS now inherits headphone-only audio selection for future builds.
Observed:board cards Dummy0,Loopback1,Codec2,I2Smaster3. Default ALSA points to
old BlueALSA MAC and plugin missing; Codec headphone muted/volume0, DAC63.
Change:default plug hw:Codec,0 and ctl hw Codec; persistent mixer DAC/direct
headphone, switch on, volume40/63. Disable I2S nodes via separate DTB.
Rollback:board /root/aic_miracast/candidates/headphone_20260930/rollback.
Build:DTB only; preserve running #246 zImage and modules. No kernel/source
driver edit. No GitHub push or automatic Bluetooth/Miracast startup changes.
Tests/commit/decision:pending; software playback checks do not prove audible output.

Source:kernelb1deb8b, runtime2359092. DTB compile succeeded with inherited
preexisting DT warnings. DTB MD5:670b67cf44be2d21acdca82dab9e3d4b;
asound.conf b38839aeeb2c132931546aec6877e74f; S20headphone497f0e98f7ec58fc43acbe4b4b2dea1b.
Deployed via SCP, target hashes checked. OldDTB c9904bd6d2e90634e165895928f804c6,
oldasound c27808871ed0372b07d4bce03f085d65 preserved under candidate/rollback.
FAT DTB replaced as filesystem file, sync/unmount completed; zImage unchanged
2b9b8cf3f41d88fc7182be2c63bcdf22. No BT kernel/module deployment.
One software reboot via /sbin/reboot (plain reboot absent from SSH PATH).
Observed boot51098f04-9c36-427e-9e42-ccc1322483b5, kernel5.7.1 #246.
Cards:Dummy0,Loopback1,Codec2 only, no I2Smaster. Three I2S-related DT nodes
disabled. amixer default now opens Codec, Headphone40/63(-23dB),switchon.
aplay -D default -t raw -f S16_LE -r48000 -c2 -d1 /dev/zero completed.
SSH auto-network restored; card0/rtc0/TCA present, S46AIC/S47IP hashes unchanged.
Decision:configuration deployed and directly verified; audible output and physical
cold-boot/full regression acceptance not claimed. Archive:headphone_20260930.
Rollback:restore candidate/rollback/asound.conf to /etc/asound.conf, remove only
the newly installed S20headphone, restore oldDTB on FAT then sync/unmount/reboot.
Previous headphone mixer was sourceDAC,volume0,switchoff,DACvolume63.
Temporary commit wrappers removed; build/startup tools are durable tracked files.

## 2026-09-30 / pending boot evidence / SPI1 Flash investigation
Files:f1c200s/newboard_flash_20260930/read-brom.c and Chinese/English records.
Tool source commits:dad91b1,8fd520b; compile passed with original ARM toolchain.
Purpose:read-only ROM mapping to resolve user's SD-first/no-card-SPI1 boot request.
Both mappings failed in userspace,0byte output; no valid ROM acquired.
No Flash register writes, flash erase, kernel edit/deployment/reboot or hardware
changes. Existing kernel config and BT/WLAN candidate unchanged.
Current Linux panel init claims PA0 whereas new schematic assigns PA0 FlashCS;
do not enable SPI1 blindly or claim usable storage/boot until conflict handled.
ROM SPI1 path unproven; requires FEL/exact-ROM evidence with user coordination.
Detailed source records in f1c200s/newboard_flash_20260930. No stable acceptance,
new worktree or GitHub push. Remove temporary diagnostics after the read attempt.

## 2026-09-30 / planned / RTL8723DS Bluetooth preparation
Base:253c58b; tagged rtl8723ds-before-bluetooth-20260930.
Full source preserved at /home/wnk/F1C200S_archives/rtl8723ds_bt_baseline_20260930/driver-source.bundle.
Files:staged complete native HCIUART H5 sources/headers, Kbuild, firmware/license,
combined DTS, build tools, loader and docs. Kernel only enables prerequisite config;
external adaptation is not merged into kernel driver source before acceptance.
Hardware:UART2 PE7/8/9/10; enable P03 active-high (BT_DIS# release),
device-wake P04, host-wake P02 input; lpo clock from PCF8563.
Hypothesis:native Realtek H5+btrtl firmware download supports 8723DS after an
explicit realtek,rtl8723ds-bt OF match and external-clock lifetime handling.
Firmware:armbian/firmware pinned2a9e1c19460401443267926181191d57e3ff175d;
rtl8723ds_fw.bin48988 bytes, config47 bytes. Preserve upstream config unchanged.
Config UART entry:1.5Mbaud and hardware flow control; hardware validation pending.
Protected:current AIC, USB/MUSB, display, RTC/IP settings; no board deployment.
Build and decision:pending compile; no Bluetooth/pairing/audio acceptance claim.

Implementation commits:kernel b13545f, external1f1c430.
Build:tmux f1-rtl8723ds-bt-0930, numeric rc0. Whole build incrementally in
original trees; no clean/mrproper/O= or new worktree. Native kernel driver
sources unchanged; external H5 diff adds 8723DS OF match, managed lpo clock,
and a read-only host-wake GPIO reservation. No host-wake interrupt/suspend
wakeup-source implemented or claimed.
Firmware parser checks pinned SHA256, magic/entry lengths, 1.5M UART code and
hardware flow-control bit. Firmware Git blob IDs match pinned Armbian tree.
DTB fdtget verified UART2 okay, PE7/8/9/10, enable P03 active-high,
device-wake P04, host-wake P02, assigned32768Hz, UART0 okay, MMC1 one-bit.
Module hci_uart MD5:63b62d1042dbacffdaec40acb1d83848.
btrtl MD5:0761a0b2bd090aace818954b8254ca5e.
zImage MD5:75da971835ca3339b47eb649c2cf6697.
Combined DTB MD5:7f26f842d7180355a6e07c398ecb8ef7.
Config MD5:0361a6dd67d2d74f23dcb147148e8d38.
WLAN module remains865feaabcc2f1821707a91d9dde61563. Matched USB/Cedar/ION
modules rebuilt and verified5.7.1; their hashes remain identical to #246.
System.map now contains serdev driver registration and TTY/serdev bridge.
Observed running board still5.7.1 #246; S46AIC/S47IP hashes unchanged.
No board file changes, no reboot or hardware test. No GitHub push.
Loader packaging follow-up:include both manual loaders in the artifact package;
load candidate btrtl by explicit adjacent path instead of relying on an absent
board module index. Script-only syntax/guard check; module binaries unchanged.
Archive:/home/wnk/F1C200S_archives/rtl8723ds_bt_candidate_20260930.
Decision:compile-verified preparation only; hardware acceptance pending.

Worktree: /home/wnk/LicheePi_Nano/third_party/rtl8723ds
Component: external RTL8723DS SDIO driver and new-board DTS candidate
Base: 52e593e8c889b68ba58bd51cbdbcad7fe71362e4; full source tracked
Target release: 5.7.1
Purpose: prepare one-bit SDIO WLAN before the module is soldered.

## 2026-09-30 / planned / schematic-based WLAN preparation
Hypothesis: the existing genuine RTL8723D SDIO driver and suniv MMC host
can support MMC1 on PC0/PC1/PC2 with a one-bit bus and TCA P01 reset.
Files: f1c200s/newboard_20260930 DTS, build/load tools, BT config, README.
Protected dependencies: MMC0/rootfs, USB/MUSB/AIC, display PC3, RTC CLKOUT,
TCA address0x20 and P17 RTC IRQ, IP5209 settings. No changes to those sources.
Commit: 865d5bf96654048d2d73f999679f2102fff3673d.
Build: build.sh; GCC Linaro7.2.1; LOCALVERSION=; external module and DTB only.
Deploy and rollback: no board deployment. Prior source tag
rtl8723ds-before-newboard-20260930; archive
/home/wnk/F1C200S_archives/rtl8723ds_baseline_20260930.
Kernel source/artifact reference:
/home/wnk/F1C200S_archives/rtc_ip5209_b8b1d71_20260930.
Tests: tmux build rc=0; vermagic=5.7.1 mod_unload ARMv5 p2v8;
aliases include 024c:d723/d724. No-device load guard returned nonzero without
loading a module. DTB values verified using fdtget: bus-width1, 25MHz,
IRQ24, PC0 clock, PC1/PC2 CMD/D0, TCA P01 active-low reset, P00 IRQ falling.
Decision: pending hardware installation; no acceptance or GitHub push.
Bluetooth: current kernel lacks HCIUART/serdev; do not enable BT or host-wake.
Pinout correction after enlarged schematic inspection: WLINT=P00,
WLRST=P01, BTINT=P02, BTRST=P03, BTWAKE=P04. A2 is grounded.
The first inspection incorrectly associated nets with the preceding pin row;
that interpretation was corrected before uploading or building any candidate.

## 2026-09-30 / pending hardware / completed build verification
Build command: bash f1c200s/newboard_20260930/build.sh, carried by tmux
f1-rtl8723ds-0930 via build-session.sh. Numeric rc0 in
/tmp/f1-rtl8723ds-0930.rc; persistent shell retained.
Module MD5: 865feaabcc2f1821707a91d9dde61563.
DTB MD5: c0507192bb648018e595cd5d35768eb3.
Module SHA256: 0a8f8144e12fe22aa1cf4d28cb876ea48118b56da5c99ebebfdfad5caad8d62a.
DTB SHA256: e815eabfe00943e4a6d7e7b8a820052f531cc119e3f672714af096432af09b56.
Warnings: vendor div64 pointer-type warning and inherited DT graph/unit-address
warnings; no build error. No speculative cleanup of unrelated kernel DTS.
Static protected checks: MMC0 okay; panel-dpi retained; USB host okay;
TCA address32, parent PE5 IRQ unchanged; RTC child IRQ15 falling unchanged;
UART2 disabled. Kernel tracked source/config unchanged. Existing zImage MD5
2b9b8cf3f41d88fc7182be2c63bcdf22 and current RTC DTB MD5
c9904bd6d2e90634e165895928f804c6 unchanged.
Board runtime observed:5.7.1 #246, TCA driver bound, card0 present;
S46AIC and S47IP hashes unchanged. No deployment/reboot/runtime settings changed.
Artifacts and source bundle: /home/wnk/F1C200S_archives/rtl8723ds_candidate_20260930.
Decision: compile-verified candidate only. WLAN association, BT, suspend/wake,
physical cold-boot acceptance and functional regressions await soldered hardware.
No GitHub push. Temporary registration wrapper removed after execution.

Documentation-only follow-up: accept the user's confirmed UART wiring and
replace the disabled UART2 node's stale pin41 comment with the actual software
gate (HCIUART/serdev not enabled). No DT properties or driver code changed.
